# -*- coding: utf-8 -*-
"""
Modulo de configuracao do Mangaba.

Contem utilitarios para configuracao do framework.
"""

from mangaba.config.api import configure_api 