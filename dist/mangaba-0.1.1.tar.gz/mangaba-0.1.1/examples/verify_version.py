import mangaba
print(mangaba.__version__)