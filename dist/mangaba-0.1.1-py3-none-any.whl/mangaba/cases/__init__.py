# -*- coding: utf-8 -*-
"""
Modulo de casos de uso do Mangaba.

Contem implementacoes de exemplos prontos para uso.
"""

from mangaba.cases.cases import case_mercado, case_educacao, main 